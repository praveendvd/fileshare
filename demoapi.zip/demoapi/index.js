const app = require('express')();
const bodyParser = require('body-parser');
const https = require('https');
const fs = require('fs');
const args = require('yargs').argv;
swaggerJsdoc = require("swagger-jsdoc"),
    swaggerUi = require("swagger-ui-express");

const options = {
    definition: {
        openapi: "3.0.0",
        info: {
            title: "Postman Test Automation Training",
            version: "1.0.0",
            description: "This is a simple CRUD API application made with Express and documented with Swagger, for postman training",
            license: {
                name: "MIT",
            },
            contact: {
                name: "Praveen David Mathew",
                email: "PraveenMathew@eurofins.ie",
            },
        },
        servers: [{
            url: "https://localhost:3000",
        }, ],
    },
    apis: ["./index.js"],
};


const specs = swaggerJsdoc(options);

app.use(
    "/swagger",
    swaggerUi.serve,
    swaggerUi.setup(specs, {
        explorer: true
    })
);


app.use(bodyParser.json());

const port = args.port;

data = []

https.createServer({
        key: fs.readFileSync('./test_key.pem'),
        cert: fs.readFileSync('./test_cert.pem'),
        passphrase: 'test_secret_qa'
    }, app)
    .listen(port, '127.0.0.1', console.log(`The api service have started at port ${port} , \n Navigate to swagger : https://localhost:3000/swagger/ `));


/**
 *  @swagger
 *  tags:
 *    name: user
 *    description: API to manage your user accounts .
 */

/** 
 *    @swagger
 *     components:
 *       schemas:
 *         user:
 *           type: object
 *           required:
 *             - name
 *             - job
 *           properties:
 *             name:
 *               type: string
 *               description: Name of the user.
 *             job:
 *               type: string
 *               description: Job of the user
 *           example:
 *             name: Praveen Mathew
 *             job: QA
 */

/** 
 *    @swagger
 *     components:
 *       schemas:
 *         usernotexist:
 *           type: object
 *           required:
 *             - error
 *           properties:
 *             error:
 *               type: string
 *               description: The error message for get operation.
 *           example:
 *             error: user not found
 */


/**
 *  @swagger
 *  path:
 *   /user:
 *     get:
 *       summary: Fetch user details for the provided ID
 *       tags: [user]
 *       parameters:
 *         - in: query
 *           name: id
 *           schema:
 *             type: integer
 *           required: true        
 *       responses:
 *         "200":
 *           description: The Fetched user details.
 *           content:
 *             application/json:
 *               schema:
 *                 $ref: '#/components/schemas/user'
 *         "404":
 *           description: Response for non existing user.
 *           content:
 *             application/json:
 *               schema:
 *                 $ref: '#/components/schemas/usernotexist'
 */


app.get('/user', (req, res) => {

    let id = req.query.id

    /*
       some code to connect to database 

    */
    let userdetails = [{
            "name": "Praveen",
            "job": "QA Engineer"
        },
        {
            "name": "David",
            "job": "QA Engineer"
        },
        {
            "name": "Mathew",
            "job": "QA Engineer"
        }
    ]

    let user = userdetails[id]
    user ? res.status(200).send(user) : res.status(404).send({
        "error": "user not found"
    })
});



/** 
 *    @swagger
 *     components:
 *       schemas:
 *         user:
 *           type: object
 *           required:
 *             - name
 *             - job
 *           properties:
 *             name:
 *               type: string
 *               description: Name of the user.
 *             job:
 *               type: string
 *               description: Job of the user
 *           example:
 *             name: Praveen Mathew
 *             job: QA
 */

/** 
 *    @swagger
 *     components:
 *       schemas:
 *         usernotexist:
 *           type: object
 *           required:
 *             - error
 *           properties:
 *             error:
 *               type: string
 *               description: The error message for get operation.
 *           example:
 *             error: user not found
 */


/**
 *  @swagger
 *  path:
 *   /check:
 *     get:
 *       summary: Demo end point to show non standard response
 *       tags: [user]
 *       responses:
 *         "200":
 *           description: The Fetched user details.
 *           content:
 *             application/json:
 *               schema:
 *                 $ref: '#/components/schemas/user'
 *         "404":
 *           description: Response for non existing user.
 *           content:
 *             application/json:
 *               schema:
 *                 $ref: '#/components/schemas/usernotexist'
 */


// A public function saying if user do a get request to /check endpoint then :
// Return a status code 899( To show status code is set by developer and its not something magical that you will get )
// return a response like {"age":"Check my status code :D"}
app.get('/check', (req, res) => {
    res.status(899).send({
        "age": "Check my status code :D"
    });
});

/** 
 *    @swagger
 *     components:
 *       schemas:
 *         user:
 *           type: object
 *           required:
 *             - name
 *             - job
 *           properties:
 *             name:
 *               type: string
 *               description: Name of the user.
 *             job:
 *               type: string
 *               description: Job of the user
 *           example:
 *             name: Praveen Mathew
 *             job: QA
 */

/** 
 *    @swagger
 *     components:
 *       schemas:
 *         usernotexist:
 *           type: object
 *           required:
 *             - error
 *           properties:
 *             error:
 *               type: string
 *               description: The error message for get operation.
 *           example:
 *             error: user not found
 */


/**
 *  @swagger
 *  path:
 *   /404:
 *     get:
 *       summary: Show status 404
 *       tags: [user]
 *       parameters:
 *         - in: query
 *           name: id
 *           schema:
 *             type: integer
 *           required: true     
 *       responses:
 *         "200":
 *           description: The Fetched user details.
 *           content:
 *             application/json:
 *               schema:
 *                 $ref: '#/components/schemas/user'
 *         "404":
 *           description: Response for non existing user.
 *           content:
 *             application/json:
 *               schema:
 *                 $ref: '#/components/schemas/usernotexist'
 */
app.get('/404', (req, res) => {
    res.status(404).send({
        "Status code": 404,
        "Message": "This is just a lie this page exist!!!!!!!!!!!!!!, ask the DEVELOPER to fix the STATUS CODE to 200",
        "user": {
            "name": "Praveen David Mathew",
            "Job": "QA Engineer"
        }
    });
});